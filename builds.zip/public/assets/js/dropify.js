//Dropify
$(document).ready(function () {
    $('.dropify').dropify({
        messages: {
            'default': 'Seret Gambar ke sini atau Klik',
            'replace': 'Seret Gambar ke sini atau Klik untuk mengganti',
            'remove': 'Buang',
            'error': 'Waduh, terjadi suatu kesalahan'
        }
    });
})